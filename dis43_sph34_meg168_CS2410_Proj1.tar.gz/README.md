# CS2410_Project1

>tar -xzvf dis43_meg168_sph34_CS2410_Proj1.tar.gz

>cd dis43_meg168_sph34_CS2410_Proj1/TomasuloSimulator

>make clean

>make

For part 1:

>./TomasuloSimulator Benchmarks/Test1.dat

For part 2:

>./TomasuloSimulator Benchmarks/Test1.dat Benchmarks/Test1.dat

In order to change configuration files:

>vim Config/TomasuloSimulator.conf

